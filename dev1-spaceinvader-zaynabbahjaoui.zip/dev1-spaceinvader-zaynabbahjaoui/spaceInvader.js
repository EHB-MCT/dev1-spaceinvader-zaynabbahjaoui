"use strict";

let canvas = document.querySelector("Canvas");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let context = canvas.getContext("2d");


function drawSpaceInvader() {



context.lineWidth = 455;
context.strokeStyle ='#59FF00';
context.beginPath();
context.lineTo(665,280);
context.lineTo(660,75);
context.stroke()

    
}

