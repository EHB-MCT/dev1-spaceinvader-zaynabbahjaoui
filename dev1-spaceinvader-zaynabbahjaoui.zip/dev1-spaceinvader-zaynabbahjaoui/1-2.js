"use strict";

let canvas = document.querySelector("Canvas");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
let context = canvas.getContext("2d");

drawColoredBox();

function drawColoredBox() {

context.lineWidth = 150;
context.height= 150;
context.strokeStyle = 'black';

context.beginPath();
context.lineWidth(50,50);
context.lineWidth(50,115);

}